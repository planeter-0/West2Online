package com.assessment2;

public interface FriedChickenRestaurant {
    void sellSetMeal(SetMeal object);
    void bulkPurchase(Drinks drink, int num);
}
