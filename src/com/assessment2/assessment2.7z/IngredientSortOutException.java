package com.assessment2;

public class IngredientSortOutException extends RuntimeException {
    public IngredientSortOutException() {
    }

    public IngredientSortOutException(String message) {
        super(message);
    }
}
